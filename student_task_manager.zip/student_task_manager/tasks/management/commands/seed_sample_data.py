"""
Creates a sample student and sample assignments for demonstration.

Usage:
    python manage.py seed_sample_data --password YourChosenPassword

The password is given on the command line so that it is NOT stored in the
source code. Running the command again resets that student's sample data.
"""
from datetime import timedelta

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.utils import timezone

from tasks.models import Assignment


class Command(BaseCommand):
    help = "Create a sample student with demo assignments (pending, completed and overdue)."

    def add_arguments(self, parser):
        parser.add_argument("--username", default="student1", help="Username (default: student1)")
        parser.add_argument("--password", required=True, help="Password for the sample student")

    def handle(self, *args, **options):
        username = options["username"]

        # get_or_create: reuse the user if it already exists
        user, created = User.objects.get_or_create(username=username)
        user.set_password(options["password"])  # stores a HASH, never the plain text
        user.save()

        # Start clean so running the command twice doesn't duplicate rows
        user.assignments.all().delete()

        today = timezone.localdate()
        P, C = Assignment.STATUS_PENDING, Assignment.STATUS_COMPLETED
        LOW, MED, HIGH = Assignment.PRIORITY_LOW, Assignment.PRIORITY_MEDIUM, Assignment.PRIORITY_HIGH

        # (title, description, subject, days from today, priority, status)
        samples = [
            ("Binary Search Tree implementation", "Insert, delete and traversals in C++.", "Data Structures", 3, HIGH, P),
            ("ER diagram for Library System", "Draw ER diagram and convert to tables.", "DBMS", 7, MED, P),
            ("CPU scheduling practical file", "FCFS, SJF and Round Robin with Gantt charts.", "Operating Systems", -4, HIGH, P),
            ("OSI vs TCP/IP report", "2-page comparison with diagrams.", "Computer Networks", -10, MED, C),
            ("Django mini project", "Student task manager for the final demo.", "Python", 14, HIGH, P),
            ("Probability worksheet", "Solve questions 1 to 15.", "Mathematics", -2, LOW, P),
            ("SRS document", "Software Requirement Specification for the project.", "Software Engineering", 10, LOW, C),
            ("Portfolio web page", "HTML + CSS personal portfolio.", "Web Technology", 1, MED, P),
        ]

        for title, description, subject, days, priority, status in samples:
            Assignment.objects.create(
                owner=user,
                title=title,
                description=description,
                subject=subject,
                due_date=today + timedelta(days=days),
                priority=priority,
                status=status,
            )

        self.stdout.write(self.style.SUCCESS(
            f"Sample student '{username}' ready with {len(samples)} assignments "
            f"(2 overdue, 2 completed)."
        ))
