from django.apps import AppConfig


class TasksConfig(AppConfig):
    """Tells Django that 'tasks' is an app and what its name is."""
    default_auto_field = "django.db.models.BigAutoField"
    name = "tasks"
