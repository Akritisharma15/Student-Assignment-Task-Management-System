"""
Database model for the project.

A Django *model* is a Python class. Each class becomes a table in SQLite and
each attribute becomes a column. We never write SQL ourselves: Django's ORM
(Object Relational Mapper) translates our Python code into SQL.
"""
from django.conf import settings
from django.db import models
from django.utils import timezone


class AssignmentQuerySet(models.QuerySet):
    """
    Extra reusable query methods for Assignment.
    Lets us write  Assignment.objects.overdue()  anywhere in the project.
    """

    def overdue(self):
        # Overdue = NOT completed (i.e. pending) AND due date is before today.
        # 'due_date__lt' means "due_date is less than".
        return self.filter(
            status=Assignment.STATUS_PENDING,
            due_date__lt=timezone.localdate(),
        )


class Assignment(models.Model):
    # --- Allowed values for the choice fields -----------------------------
    # Each pair is (value stored in the database, label shown to the user).
    PRIORITY_LOW = "low"
    PRIORITY_MEDIUM = "medium"
    PRIORITY_HIGH = "high"
    PRIORITY_CHOICES = [
        (PRIORITY_LOW, "Low"),
        (PRIORITY_MEDIUM, "Medium"),
        (PRIORITY_HIGH, "High"),
    ]

    STATUS_PENDING = "pending"
    STATUS_COMPLETED = "completed"
    STATUS_CHOICES = [
        (STATUS_PENDING, "Pending"),
        (STATUS_COMPLETED, "Completed"),
    ]

    # --- Fields (columns) ---------------------------------------------------
    # ForeignKey = "each assignment belongs to exactly ONE user".
    # on_delete=CASCADE: if a user is deleted, their assignments are deleted too.
    # related_name='assignments': lets us write  user.assignments.all()
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="assignments",
    )
    title = models.CharField(max_length=200)           # short text
    description = models.TextField(blank=True)         # long text, optional
    subject = models.CharField(max_length=100)         # e.g. "DBMS"
    due_date = models.DateField()                      # date only (no time)
    priority = models.CharField(
        max_length=10, choices=PRIORITY_CHOICES, default=PRIORITY_MEDIUM
    )
    status = models.CharField(
        max_length=10, choices=STATUS_CHOICES, default=STATUS_PENDING
    )
    created_at = models.DateTimeField(auto_now_add=True)  # set once, automatically

    # Attach our custom query methods (gives us Assignment.objects.overdue()).
    objects = AssignmentQuerySet.as_manager()

    class Meta:
        # Default sort order: earliest due date first, then newest created.
        ordering = ["due_date", "-created_at"]

    def __str__(self):
        # What you see in the admin list and in the Django shell.
        return f"{self.title} ({self.subject})"

    # --- Helper properties used by templates and tests ----------------------
    @property
    def is_completed(self):
        return self.status == self.STATUS_COMPLETED

    @property
    def is_overdue(self):
        """
        Overdue is NOT stored in the database. It is calculated every time
        from two facts, so it can never be out of date:
            due date has passed  AND  status is not completed.
        """
        return (not self.is_completed) and self.due_date < timezone.localdate()
