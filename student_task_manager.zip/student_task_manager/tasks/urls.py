"""
URLs of the 'tasks' app: maps a web address to a view function.
app_name lets us refer to them as  {% url 'tasks:dashboard' %}.
"""
from django.contrib.auth import views as auth_views
from django.urls import path

from . import views
from .forms import LoginForm

app_name = "tasks"

urlpatterns = [
    # Authentication (login/logout use Django's ready-made views)
    path("register/", views.register, name="register"),
    path(
        "login/",
        auth_views.LoginView.as_view(
            template_name="tasks/login.html",
            authentication_form=LoginForm,
            redirect_authenticated_user=True,
        ),
        name="login",
    ),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),

    # Dashboard (home page)
    path("", views.dashboard, name="dashboard"),

    # Assignment CRUD
    path("assignments/add/", views.assignment_create, name="assignment_create"),
    path("assignments/<int:pk>/", views.assignment_detail, name="assignment_detail"),
    path("assignments/<int:pk>/edit/", views.assignment_update, name="assignment_update"),
    path("assignments/<int:pk>/delete/", views.assignment_delete, name="assignment_delete"),
    path("assignments/<int:pk>/complete/", views.assignment_complete, name="assignment_complete"),
]
