"""
Forms. A Django form:
  * draws the HTML inputs,
  * validates what the user typed,
  * (ModelForm) can save the data straight into the database.
"""
from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from .models import Assignment


def add_bootstrap_classes(form):
    """Give every input the Bootstrap class so it looks nice."""
    for field in form.fields.values():
        css = "form-select" if isinstance(field.widget, forms.Select) else "form-control"
        field.widget.attrs["class"] = css


class AssignmentForm(forms.ModelForm):
    """Form built automatically from the Assignment model."""

    class Meta:
        model = Assignment
        # 'owner' and 'created_at' are NOT here: the view sets the owner
        # from request.user, so a student can never choose another owner.
        fields = ["title", "description", "subject", "due_date", "priority", "status"]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
            # type="date" shows a calendar picker. 'format' lets the Edit page
            # pre-fill the existing date correctly.
            "due_date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        add_bootstrap_classes(self)

    def clean_title(self):
        # Custom validation: runs automatically for the 'title' field.
        title = self.cleaned_data["title"].strip()
        if len(title) < 3:
            raise forms.ValidationError("Title must be at least 3 characters long.")
        return title


class RegisterForm(UserCreationForm):
    """Django's built-in sign-up form (username + 2 passwords) with Bootstrap styling."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        add_bootstrap_classes(self)


class LoginForm(AuthenticationForm):
    """Django's built-in login form with Bootstrap styling."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        add_bootstrap_classes(self)
