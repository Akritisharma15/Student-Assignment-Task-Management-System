"""
Views = the Python functions that handle a request and return a page.
Every assignment view is protected by @login_required, and every query is
restricted to  owner=request.user  so students only ever touch their own data.
"""
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import AssignmentForm, RegisterForm
from .models import Assignment


def get_user_assignment_or_404(request, pk):
    """
    Fetch ONE assignment by id, but only if it belongs to the logged-in user.
    If it belongs to someone else (or doesn't exist) Django shows a 404 page.
    This single helper is what enforces "students can't see/modify others' work".
    """
    return get_object_or_404(Assignment, pk=pk, owner=request.user)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------
def register(request):
    if request.user.is_authenticated:
        return redirect("tasks:dashboard")

    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():          # runs all validation (passwords match, strong, ...)
            user = form.save()       # creates the user (password is hashed automatically)
            login(request, user)     # log them in straight away
            messages.success(request, "Account created. Welcome!")
            return redirect("tasks:dashboard")
    else:
        form = RegisterForm()        # empty form for a GET request

    return render(request, "tasks/register.html", {"form": form})


# ---------------------------------------------------------------------------
# Dashboard: statistics + search/filter + assignment table
# ---------------------------------------------------------------------------
@login_required
def dashboard(request):
    # Start from ONLY this user's assignments.
    my_assignments = Assignment.objects.filter(owner=request.user)

    # ---- Statistics for the cards ----
    stats = {
        "total": my_assignments.count(),
        "completed": my_assignments.filter(status=Assignment.STATUS_COMPLETED).count(),
        "pending": my_assignments.filter(status=Assignment.STATUS_PENDING).count(),
        "overdue": my_assignments.overdue().count(),
        # High priority that still needs doing (not completed)
        "high_priority": my_assignments.filter(
            priority=Assignment.PRIORITY_HIGH, status=Assignment.STATUS_PENDING
        ).count(),
    }

    # ---- Read search/filter values from the URL, e.g. ?q=lab&priority=high ----
    q = request.GET.get("q", "").strip()
    subject = request.GET.get("subject", "")
    priority = request.GET.get("priority", "")
    status = request.GET.get("status", "")

    assignments = my_assignments
    if q:
        assignments = assignments.filter(title__icontains=q)       # search by title
    if subject:
        assignments = assignments.filter(subject__iexact=subject)  # filter by subject
    if priority in dict(Assignment.PRIORITY_CHOICES):
        assignments = assignments.filter(priority=priority)        # filter by priority
    if status == "overdue":
        assignments = assignments.overdue()                        # derived status
    elif status in dict(Assignment.STATUS_CHOICES):
        assignments = assignments.filter(status=status)            # pending / completed

    # Subjects for the dropdown: only this user's subjects, no duplicates.
    subjects = (
        my_assignments.order_by("subject")
        .values_list("subject", flat=True)
        .distinct()
    )

    context = {
        "assignments": assignments,
        "stats": stats,
        "subjects": subjects,
        "priority_choices": Assignment.PRIORITY_CHOICES,
        "status_choices": Assignment.STATUS_CHOICES + [("overdue", "Overdue")],
        "filters": {"q": q, "subject": subject, "priority": priority, "status": status},
        "has_filters": any([q, subject, priority, status]),
    }
    return render(request, "tasks/dashboard.html", context)


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------
@login_required
def assignment_create(request):
    if request.method == "POST":
        form = AssignmentForm(request.POST)
        if form.is_valid():
            assignment = form.save(commit=False)  # build the object, don't save yet
            assignment.owner = request.user       # attach the logged-in user as owner
            assignment.save()                     # now INSERT into the database
            messages.success(request, "Assignment added.")
            return redirect("tasks:dashboard")
    else:
        form = AssignmentForm()
    return render(
        request, "tasks/assignment_form.html", {"form": form, "page_title": "Add Assignment"}
    )


@login_required
def assignment_detail(request, pk):
    assignment = get_user_assignment_or_404(request, pk)
    return render(request, "tasks/assignment_detail.html", {"assignment": assignment})


@login_required
def assignment_update(request, pk):
    assignment = get_user_assignment_or_404(request, pk)
    if request.method == "POST":
        # instance=assignment means "update this row" instead of "create a new one"
        form = AssignmentForm(request.POST, instance=assignment)
        if form.is_valid():
            form.save()
            messages.success(request, "Assignment updated.")
            return redirect("tasks:dashboard")
    else:
        form = AssignmentForm(instance=assignment)  # pre-filled with current values
    return render(
        request, "tasks/assignment_form.html", {"form": form, "page_title": "Edit Assignment"}
    )


@login_required
def assignment_delete(request, pk):
    assignment = get_user_assignment_or_404(request, pk)
    if request.method == "POST":       # only delete after the user confirms
        assignment.delete()
        messages.success(request, "Assignment deleted.")
        return redirect("tasks:dashboard")
    return render(request, "tasks/assignment_confirm_delete.html", {"assignment": assignment})


@login_required
@require_POST   # changing data must be a POST (never a GET link)
def assignment_complete(request, pk):
    assignment = get_user_assignment_or_404(request, pk)
    assignment.status = Assignment.STATUS_COMPLETED
    assignment.save()
    messages.success(request, f'"{assignment.title}" marked as completed.')
    return redirect("tasks:dashboard")
