"""
Basic automated tests. Run them with:   python manage.py test
Django creates a temporary empty database for the tests, so your real
data in db.sqlite3 is never touched.
"""
import secrets
from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .forms import AssignmentForm
from .models import Assignment


def make_assignment(owner, **overrides):
    """Small helper that creates an assignment with sensible defaults."""
    data = {
        "title": "Sample assignment",
        "subject": "DBMS",
        "due_date": timezone.localdate() + timedelta(days=5),
    }
    data.update(overrides)
    return Assignment.objects.create(owner=owner, **data)


class BaseTestCase(TestCase):
    def setUp(self):
        # Random passwords generated for every run (nothing hard-coded).
        self.password = secrets.token_urlsafe(12)
        self.alice = User.objects.create_user("alice", password=self.password)
        self.bob = User.objects.create_user("bob", password=self.password)

    def login_as(self, username):
        self.client.login(username=username, password=self.password)


class LoginRequiredTests(BaseTestCase):
    def test_dashboard_redirects_anonymous_user_to_login(self):
        response = self.client.get(reverse("tasks:dashboard"))
        expected = f"{reverse('tasks:login')}?next={reverse('tasks:dashboard')}"
        self.assertRedirects(response, expected)

    def test_all_assignment_pages_need_login(self):
        a = make_assignment(self.alice)
        urls = [
            reverse("tasks:assignment_create"),
            reverse("tasks:assignment_detail", args=[a.pk]),
            reverse("tasks:assignment_update", args=[a.pk]),
            reverse("tasks:assignment_delete", args=[a.pk]),
        ]
        for url in urls:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 302, msg=url)
            self.assertIn(reverse("tasks:login"), response.url)


class AuthenticationTests(BaseTestCase):
    def test_register_creates_user_and_logs_in(self):
        new_password = secrets.token_urlsafe(16)
        response = self.client.post(reverse("tasks:register"), {
            "username": "carol",
            "password1": new_password,
            "password2": new_password,
        })
        self.assertRedirects(response, reverse("tasks:dashboard"))
        self.assertTrue(User.objects.filter(username="carol").exists())

    def test_login_with_correct_password(self):
        response = self.client.post(
            reverse("tasks:login"), {"username": "alice", "password": self.password}
        )
        self.assertRedirects(response, reverse("tasks:dashboard"))

    def test_logout(self):
        self.login_as("alice")
        response = self.client.post(reverse("tasks:logout"))
        self.assertRedirects(response, reverse("tasks:login"))
        # After logout the dashboard is protected again
        self.assertEqual(self.client.get(reverse("tasks:dashboard")).status_code, 302)


class AssignmentCreationTests(BaseTestCase):
    def test_create_assignment_sets_logged_in_user_as_owner(self):
        self.login_as("alice")
        response = self.client.post(reverse("tasks:assignment_create"), {
            "title": "Write report",
            "description": "Chapter 1",
            "subject": "Networks",
            "due_date": (timezone.localdate() + timedelta(days=3)).isoformat(),
            "priority": "high",
            "status": "pending",
        })
        self.assertRedirects(response, reverse("tasks:dashboard"))
        assignment = Assignment.objects.get(title="Write report")
        self.assertEqual(assignment.owner, self.alice)

    def test_title_too_short_is_rejected(self):
        form = AssignmentForm(data={
            "title": "ab", "subject": "DBMS",
            "due_date": timezone.localdate().isoformat(),
            "priority": "low", "status": "pending",
        })
        self.assertFalse(form.is_valid())
        self.assertIn("title", form.errors)


class OwnershipTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.alice_assignment = make_assignment(self.alice, title="Alice only")

    def test_dashboard_shows_only_own_assignments(self):
        make_assignment(self.bob, title="Bob only")
        self.login_as("alice")
        response = self.client.get(reverse("tasks:dashboard"))
        self.assertContains(response, "Alice only")
        self.assertNotContains(response, "Bob only")

    def test_other_user_cannot_view_edit_or_delete(self):
        self.login_as("bob")
        pk = self.alice_assignment.pk
        for name in ["assignment_detail", "assignment_update", "assignment_delete"]:
            response = self.client.get(reverse(f"tasks:{name}", args=[pk]))
            self.assertEqual(response.status_code, 404, msg=name)

    def test_other_user_cannot_modify_via_post(self):
        self.login_as("bob")
        pk = self.alice_assignment.pk
        self.client.post(reverse("tasks:assignment_delete", args=[pk]))
        self.client.post(reverse("tasks:assignment_complete", args=[pk]))
        self.alice_assignment.refresh_from_db()  # still exists, still pending
        self.assertEqual(self.alice_assignment.status, Assignment.STATUS_PENDING)

    def test_owner_can_edit_and_delete(self):
        self.login_as("alice")
        pk = self.alice_assignment.pk
        self.client.post(reverse("tasks:assignment_update", args=[pk]), {
            "title": "Renamed", "subject": "DBMS",
            "due_date": timezone.localdate().isoformat(),
            "priority": "low", "status": "pending",
        })
        self.alice_assignment.refresh_from_db()
        self.assertEqual(self.alice_assignment.title, "Renamed")

        self.client.post(reverse("tasks:assignment_delete", args=[pk]))
        self.assertFalse(Assignment.objects.filter(pk=pk).exists())


class CompletionTests(BaseTestCase):
    def test_mark_completed(self):
        a = make_assignment(self.alice)
        self.login_as("alice")
        self.client.post(reverse("tasks:assignment_complete", args=[a.pk]))
        a.refresh_from_db()
        self.assertEqual(a.status, Assignment.STATUS_COMPLETED)

    def test_complete_requires_post(self):
        a = make_assignment(self.alice)
        self.login_as("alice")
        response = self.client.get(reverse("tasks:assignment_complete", args=[a.pk]))
        self.assertEqual(response.status_code, 405)  # "Method Not Allowed"


class OverdueTests(BaseTestCase):
    def test_past_due_and_pending_is_overdue(self):
        a = make_assignment(self.alice, due_date=timezone.localdate() - timedelta(days=1))
        self.assertTrue(a.is_overdue)

    def test_past_due_but_completed_is_not_overdue(self):
        a = make_assignment(
            self.alice,
            due_date=timezone.localdate() - timedelta(days=1),
            status=Assignment.STATUS_COMPLETED,
        )
        self.assertFalse(a.is_overdue)

    def test_future_and_today_are_not_overdue(self):
        future = make_assignment(self.alice, due_date=timezone.localdate() + timedelta(days=1))
        today = make_assignment(self.alice, due_date=timezone.localdate())
        self.assertFalse(future.is_overdue)
        self.assertFalse(today.is_overdue)  # due today = still on time

    def test_overdue_queryset_and_dashboard_stats(self):
        yesterday = timezone.localdate() - timedelta(days=1)
        make_assignment(self.alice, title="Late", due_date=yesterday)
        make_assignment(self.alice, title="Late but done", due_date=yesterday,
                        status=Assignment.STATUS_COMPLETED)
        make_assignment(self.alice, title="On time")
        self.assertEqual(Assignment.objects.overdue().count(), 1)

        self.login_as("alice")
        response = self.client.get(reverse("tasks:dashboard"))
        self.assertEqual(response.context["stats"]["overdue"], 1)
        self.assertEqual(response.context["stats"]["total"], 3)
        self.assertEqual(response.context["stats"]["completed"], 1)


class SearchAndFilterTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        make_assignment(self.alice, title="Binary tree lab", subject="DSA", priority="high")
        make_assignment(self.alice, title="ER diagram", subject="DBMS", priority="low",
                        status=Assignment.STATUS_COMPLETED)
        self.login_as("alice")

    def get_titles(self, **params):
        response = self.client.get(reverse("tasks:dashboard"), params)
        return [a.title for a in response.context["assignments"]]

    def test_search_by_title(self):
        self.assertEqual(self.get_titles(q="tree"), ["Binary tree lab"])

    def test_filter_by_subject(self):
        self.assertEqual(self.get_titles(subject="DBMS"), ["ER diagram"])

    def test_filter_by_priority(self):
        self.assertEqual(self.get_titles(priority="high"), ["Binary tree lab"])

    def test_filter_by_status(self):
        self.assertEqual(self.get_titles(status="completed"), ["ER diagram"])
        self.assertEqual(self.get_titles(status="pending"), ["Binary tree lab"])
