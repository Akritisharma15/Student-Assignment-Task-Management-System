from django.contrib import admin

from .models import Assignment


@admin.register(Assignment)  # makes Assignment appear in /admin/
class AssignmentAdmin(admin.ModelAdmin):
    # Columns shown in the list page
    list_display = ("title", "owner", "subject", "due_date", "priority", "status", "overdue")
    # Filter sidebar on the right (status / priority / subject)
    list_filter = ("status", "priority", "subject")
    # Search box at the top
    search_fields = ("title", "subject", "owner__username")

    @admin.display(boolean=True, description="Overdue")
    def overdue(self, obj):
        # Shows a green tick / red cross using the model's is_overdue property
        return obj.is_overdue
