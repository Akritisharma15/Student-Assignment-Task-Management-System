# Project Guide: understand and explain this project (viva preparation)

## 1. One-paragraph summary (say this first in your viva)
"This is a Django web application where students register and log in, and manage their own assignments. I used Django's MVT pattern: the **Model** (`Assignment`) defines the database table, **Views** contain the logic, and **Templates** produce the HTML with Bootstrap styling. Authentication uses Django's built-in `auth` app. Every assignment has a `ForeignKey` to the `User`, and every query is filtered by `owner=request.user`, so students only see their own data. Overdue is calculated automatically from the due date and status."

## 2. Project vs App
- **Project** (`config/`): the whole website's settings and top-level URLs.
- **App** (`tasks/`): one feature module of the project (models, views, templates). A project can have many apps; ours has one.
- `manage.py`: the command-line tool (`runserver`, `migrate`, `test`, ...).

## 3. What happens when you open a page (request flow)
Example: a logged-in student opens `http://127.0.0.1:8000/`.
1. Browser sends `GET /`.
2. `config/urls.py` -> `include("tasks.urls")`.
3. `tasks/urls.py` matches `""` -> `views.dashboard`.
4. `@login_required` checks the session. Not logged in? -> redirect to `/login/?next=/`.
5. `dashboard` asks the database (via ORM) for **this user's** assignments, counts them, applies search/filters.
6. `render(request, "tasks/dashboard.html", context)` fills the template with that data.
7. HTML goes back to the browser; Bootstrap CSS makes it look good.

## 4. The model: `Assignment` (tasks/models.py)
| Field | Django type | Meaning |
|---|---|---|
| `owner` | `ForeignKey(User)` | The student who owns the assignment |
| `title` | `CharField(max_length=200)` | Short text |
| `description` | `TextField(blank=True)` | Long text; optional |
| `subject` | `CharField(max_length=100)` | e.g. "DBMS" |
| `due_date` | `DateField` | Deadline (date only) |
| `priority` | `CharField(choices=...)` | `low` / `medium` / `high`, default medium |
| `status` | `CharField(choices=...)` | `pending` / `completed`, default pending |
| `created_at` | `DateTimeField(auto_now_add=True)` | Filled automatically when created |
| `id` | automatic | Primary key Django adds for you |

**Choices**: stored as short values (`"high"`) in the DB, shown as labels ("High") to users. Django validates that only allowed values are saved.

**Relationship (One-to-Many):** one User -> many Assignments; each Assignment -> exactly one User.

**Why a ForeignKey to User?**
- It records *who owns* each row, which makes "my assignments only" possible: `Assignment.objects.filter(owner=request.user)`.
- The database itself guarantees an assignment can't point to a user that doesn't exist.
- `on_delete=CASCADE`: deleting a user deletes their assignments (no orphan rows).
- `related_name="assignments"` lets you write `user.assignments.all()`.
- We use `settings.AUTH_USER_MODEL` (not `User` directly) -- the recommended way to reference the user model.

**`is_overdue`** is a property, not a column:
```python
return (not self.is_completed) and self.due_date < timezone.localdate()
```
Because it is computed each time, it can never become stale -- tomorrow's overdue items appear automatically. Due *today* is NOT overdue.

## 5. How the ORM talks to SQLite
The ORM lets you write Python; Django generates and runs the SQL.

| Python (ORM) | SQL Django runs |
|---|---|
| `Assignment.objects.filter(owner=user)` | `SELECT ... FROM tasks_assignment WHERE owner_id = 1 ORDER BY due_date` |
| `.filter(title__icontains="lab")` | `... WHERE title LIKE '%lab%'` |
| `.count()` | `SELECT COUNT(*) ...` |
| `form.save()` / `assignment.save()` | `INSERT` (new) or `UPDATE` (existing) |
| `assignment.delete()` | `DELETE FROM tasks_assignment WHERE id = ...` |

Workflow: edit `models.py` -> `makemigrations` (writes a migration file = a recipe) -> `migrate` (runs it, creating/altering tables in `db.sqlite3`). The ORM also protects against **SQL injection** because values are passed as parameters, never glued into SQL text.
Tip: open a shell with `python manage.py shell` and try `from tasks.models import Assignment; Assignment.objects.all()`.

## 6. Authentication
- `User` model, password hashing, sessions and login/logout all come from `django.contrib.auth` -- we wrote almost no auth code.
- **Register**: `UserCreationForm` (built-in) validates username + password rules, hashes the password; we then call `login()`.
- **Login/Logout**: Django's `LoginView` / `LogoutView` in `tasks/urls.py`.
- **Passwords** are stored as hashes, never plain text.
- **Sessions**: after login Django stores a session id cookie; `request.user` is then available in every view.

## 7. How "students can't see each other's work" is enforced
1. `@login_required` on every view -> anonymous users are redirected to login.
2. Dashboard list: `Assignment.objects.filter(owner=request.user)`.
3. Detail/edit/delete/complete: `get_object_or_404(Assignment, pk=pk, owner=request.user)`. If you guess another student's URL, the row isn't found -> **404**.
4. `owner` is **not** a field of the form; the view sets `assignment.owner = request.user`. A student can't forge the owner by editing the HTML.
These are covered by tests in `OwnershipTests`.

## 8. Forms and validation (tasks/forms.py)
- `AssignmentForm` is a **ModelForm**: Django builds the inputs from the model.
- `form.is_valid()` runs validation: required fields, max lengths, valid date, valid choices, plus our own `clean_title` (minimum 3 characters).
- Errors are shown under each field; nothing invalid reaches the database.
- GET request -> show an empty (or pre-filled) form. POST request -> validate and save.

## 9. Security checklist
| Feature | Where |
|---|---|
| CSRF protection | `CsrfViewMiddleware` + `{% csrf_token %}` in every POST form |
| Login required | `@login_required` |
| ORM (no raw SQL) | all queries |
| Form validation | `forms.py` |
| Password hashing | Django auth |
| Secret key not in code | `settings.py` reads `DJANGO_SECRET_KEY` env var or generated `.secret_key` file |
| Dangerous actions are POST-only | complete/delete/logout |
| Template auto-escaping | `{{ variable }}` escapes HTML (prevents XSS) |

**CSRF in one line:** a hidden random token in each form proves the POST came from our site and not from a malicious page.

## 10. Search and filter
The form uses `method="get"`, so values appear in the URL: `/?q=lab&priority=high&status=pending`. The view reads them with `request.GET.get(...)` and chains `.filter()` calls onto the user's queryset. `title__icontains` = case-insensitive "contains". The "overdue" status option calls our custom `.overdue()` queryset method.

## 11. Templates
- `base.html` = navbar, messages and Bootstrap; other pages `{% extends %}` it and fill `{% block content %}`.
- `{% include %}` reuses small pieces (`_form_fields.html`, badges).
- `{% for %}`, `{% if %}`, `{% url 'tasks:...' %}` and `{{ variable }}` are Django template tags.
- `assignment_form.html` is shared by Add and Edit.

## 12. Admin panel
`admin.py` registers `Assignment` with `list_display`, `list_filter` (status, priority, subject) and `search_fields`. Login at `/admin/` with the superuser.

## 13. Tests (`python manage.py test`)
Cover: login required, registration/login/logout, creating with the right owner, ownership (404 for other users), completing (POST-only), overdue logic (past/today/future/completed), search and filters. Django runs them on a temporary database, so real data is untouched.

## 14. Likely viva questions and short answers
1. **What is Django?** A high-level Python web framework that follows MVT and includes auth, ORM, admin, forms and security features.
2. **Explain MVT.** Model = data/database; View = logic that handles requests; Template = HTML output.
3. **Difference between MVC and MVT?** In Django the framework itself plays the controller role (URL routing); Django's "View" is MVC's controller, "Template" is MVC's view.
4. **What is `settings.py`?** Central configuration: installed apps, database, middleware, templates, static files, auth redirects.
5. **What is a migration?** A Python file describing a database change; `makemigrations` creates it, `migrate` applies it.
6. **What does `ForeignKey` do?** Creates a many-to-one link (many assignments -> one user) stored as an `owner_id` column.
7. **What is `on_delete=CASCADE`?** Deleting the user also deletes their assignments.
8. **What is the ORM?** Maps Python classes to tables so we query with Python instead of SQL.
9. **How do you stop a student seeing another's assignment?** Filter by `owner=request.user` and use `get_object_or_404(..., owner=request.user)`.
10. **How is overdue detected?** `due_date < today` and status not completed; computed, not stored.
11. **Why not store overdue in the DB?** It would need daily updating and could become wrong; calculating is always correct.
12. **What is CSRF?** Cross-site request forgery; Django blocks it with a per-session token in forms.
13. **What does `@login_required` do?** Redirects anonymous users to `LOGIN_URL`.
14. **ModelForm vs Form?** ModelForm generates fields from a model and can save to the DB.
15. **Why `commit=False`?** To get the object without saving, so we can set `owner` first.
16. **GET vs POST?** GET reads/filters (safe, visible in URL); POST changes data and is CSRF-protected.
17. **What are static files?** CSS/JS/images; ours is `tasks/static/tasks/css/style.css`, loaded with `{% static %}`.
18. **What is `related_name`?** The reverse lookup name: `user.assignments.all()`.
19. **How are passwords stored?** Hashed (PBKDF2 by default), never plain text.
20. **Why is SQLite used?** Zero configuration, a single file, perfect for development and small projects.
21. **Where are the secret key and why hide it?** In an env var or `.secret_key`; it signs sessions/CSRF tokens, so leaking it is dangerous.
22. **How is the admin different from the dashboard?** Admin is for administrators over all data; the dashboard is for each student over their own.

## 15. Good things to demonstrate live
1. Register a new student -> empty dashboard.
2. Login as `student1` -> cards, overdue rows in red.
3. Add, edit, complete and delete an assignment.
4. Search and filter; click a statistic card.
5. As the second student, try opening `/assignments/1/` -> 404.
6. Open `/admin/` and show the filters.
7. Run `python manage.py test`.
