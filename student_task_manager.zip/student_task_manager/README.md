# Student Assignment & Task Management System

## Project Description
A web application built with **Django** where each student registers, logs in and manages their own assignments. A dashboard shows live statistics (total, completed, pending, overdue, high-priority) and a searchable, filterable table of assignments. Students can add, view, edit, delete and complete assignments. An assignment is automatically treated as **overdue** when its due date has passed and it is not completed. Students can never see or change each other's data.

## Features
- User registration, login and logout (Django's built-in authentication)
- Every assignment belongs to one student; other students get a 404 page if they try to open it
- Dashboard with five statistic cards (click a card to filter the table)
- Assignment CRUD: create, view, edit, delete, mark as completed
- Search by title; filter by subject, priority and status (pending / completed / overdue)
- Overdue assignments highlighted in red
- Django admin panel (view / add / edit / delete / filter assignments)
- Responsive Bootstrap 5 interface
- Automated tests (`python manage.py test`)
- CSRF protection, form validation, hashed passwords, no hard-coded secrets

## Technologies Used
| Technology | Purpose |
|---|---|
| Python 3.10+ | Programming language |
| Django 4.2 – 5.2 | Web framework |
| SQLite | Database (a single file, no setup) |
| HTML + Django Templates | Page structure |
| CSS + Bootstrap 5 (CDN) | Styling and responsive layout |

## Project Structure
```
student_task_manager/
├── manage.py                 # command-line tool (runserver, migrate, test ...)
├── requirements.txt          # Python packages needed
├── README.md
├── PROJECT_GUIDE.md          # beginner explanation + viva questions
├── config/                   # PROJECT settings
│   ├── settings.py           # all configuration
│   ├── urls.py               # top-level URL routing
│   ├── asgi.py / wsgi.py     # server entry points
└── tasks/                    # our APP
    ├── models.py             # Assignment database model
    ├── views.py              # logic for each page
    ├── forms.py              # forms + validation
    ├── urls.py               # URLs of this app
    ├── admin.py              # admin panel configuration
    ├── tests.py              # automated tests
    ├── migrations/           # database change history
    ├── management/commands/seed_sample_data.py   # creates demo data
    ├── templates/tasks/      # HTML templates
    └── static/tasks/css/     # our CSS
```
`db.sqlite3` and `.secret_key` are created automatically on first run.

## Installation
You need Python 3.10 or newer (check with `python --version`) and an internet connection (Bootstrap is loaded from a CDN).

1. Unzip the project and open a terminal inside the `student_task_manager` folder.

## Virtual Environment Setup
A virtual environment keeps this project's packages separate from the rest of your computer.

**Windows (PowerShell / CMD)**
```
python -m venv venv
venv\Scripts\activate
```
**macOS / Linux**
```
python3 -m venv venv
source venv/bin/activate
```
You should now see `(venv)` at the start of your terminal line.

## Installing Dependencies
```
pip install -r requirements.txt
```

## Database Migration
Migrations create the tables in SQLite (including our `tasks_assignment` table).
```
python manage.py makemigrations
python manage.py migrate
```
(`makemigrations` should say "No changes detected" because the migration file is already included.)

## Creating Superuser
The superuser can log in to the admin panel at `/admin/`.
```
python manage.py createsuperuser
```
Enter a username, an optional email and a password when asked (the password is typed invisibly).

## Running the Project
```
python manage.py runserver
```
Open <http://127.0.0.1:8000/> in your browser. Press `Ctrl + C` in the terminal to stop.

To run the tests: `python manage.py test`

## Sample Login
Create the demo student and 8 sample assignments with one command (you choose the password, so no password is stored in the code):
```
python manage.py seed_sample_data --password MyDemo@2025
```
Then log in at <http://127.0.0.1:8000/login/> with:

| Username | Password |
|---|---|
| `student1` | the password you passed above |

The sample data includes 8 subjects (Data Structures, DBMS, Operating Systems, Computer Networks, Python, Mathematics, Software Engineering, Web Technology), all three priorities, pending and completed assignments, and **2 overdue assignments** (the dates are calculated from today, so they are always correct).

**To show that students are isolated:** register a second student on the Register page; their dashboard will be empty and they cannot open `student1`'s assignments.

**Creating data manually instead:** log in to `/admin/` as the superuser, create a user under *Users*, then add assignments under *Assignments*, choosing that user as the owner.

## How the Application Works
1. **Browser sends a request** (for example `GET /`).
2. **`config/urls.py`** passes it to **`tasks/urls.py`**, which finds the matching **view**.
3. The **view** (`tasks/views.py`) checks the user is logged in (`@login_required`), reads/writes the database through the **model** (`Assignment`) using the ORM, and picks a **template**.
4. The **template** (`templates/tasks/*.html`) turns the data into HTML, styled by Bootstrap.
5. The HTML is sent back to the browser.

This pattern is Django's **MVT** (Model – View – Template). Ownership is enforced by always filtering with `owner=request.user`. Overdue is calculated (not stored): `due_date < today AND status != completed`. See `PROJECT_GUIDE.md` for a detailed walkthrough.

## Screenshots
_Add screenshots here before submission._

| Page | Screenshot |
|---|---|
| Login / Register | _(placeholder)_ |
| Dashboard | _(placeholder)_ |
| Add / Edit Assignment | _(placeholder)_ |
| Admin Panel | _(placeholder)_ |

## Future Improvements
- Pagination for long assignment lists
- Email or in-app reminders before a deadline
- File attachments for assignments
- Teacher role that can assign work to students
- Calendar view and sorting by column
- Deployment (e.g. PythonAnywhere) with a production database
