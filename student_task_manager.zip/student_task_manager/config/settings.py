"""
Settings for the Student Assignment & Task Management System.

Only the settings we actually care about are explained here.
"""
import os
from pathlib import Path

from django.contrib.messages import constants as message_constants
from django.core.management.utils import get_random_secret_key

# BASE_DIR = the folder that contains manage.py
BASE_DIR = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------------
# SECURITY: the secret key is NOT written in the source code.
# Django uses it to sign sessions and CSRF tokens, so it must stay private.
#   1. If the environment variable DJANGO_SECRET_KEY exists, use it.
#   2. Otherwise read it from a local file '.secret_key' (ignored by git).
#   3. If that file doesn't exist yet, generate a random key and save it.
# So a beginner can run the project with zero setup, and no key is hard-coded.
# ---------------------------------------------------------------------------
def load_secret_key():
    env_key = os.environ.get("DJANGO_SECRET_KEY")
    if env_key:
        return env_key

    key_file = BASE_DIR / ".secret_key"
    if key_file.exists():
        return key_file.read_text().strip()

    new_key = get_random_secret_key()
    key_file.write_text(new_key)
    return new_key


SECRET_KEY = load_secret_key()

# DEBUG shows detailed error pages. Fine locally, must be False in production.
DEBUG = os.environ.get("DJANGO_DEBUG", "True") == "True"

# Hosts allowed to serve the site. Empty is fine while DEBUG is True (localhost).
ALLOWED_HOSTS = [h for h in os.environ.get("DJANGO_ALLOWED_HOSTS", "").split(",") if h]


# ---------------------------------------------------------------------------
# Apps: built-in Django apps + our own app 'tasks'
# ---------------------------------------------------------------------------
INSTALLED_APPS = [
    "django.contrib.admin",         # admin panel
    "django.contrib.auth",          # users, passwords, login/logout
    "django.contrib.contenttypes",  # needed internally by auth/admin
    "django.contrib.sessions",      # remembers who is logged in
    "django.contrib.messages",      # one-time flash messages ("Assignment saved")
    "django.contrib.staticfiles",   # serves our CSS
    "tasks",                        # OUR app
]

# Middleware = small helpers that run on every request/response.
# CsrfViewMiddleware is the one that protects all our POST forms.
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",  # sets request.user
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,  # look for templates inside each app's 'templates' folder
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",  # gives templates 'user'
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"


# ---------------------------------------------------------------------------
# Database: SQLite = a single file (db.sqlite3). No server needed.
# ---------------------------------------------------------------------------
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

# Django checks passwords with these rules when someone registers.
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# ---------------------------------------------------------------------------
# Language / time. USE_TZ=True stores times in UTC; TIME_ZONE controls what
# "today" means. This matters for overdue checks (due date vs. today).
# ---------------------------------------------------------------------------
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ---------------------------------------------------------------------------
# Login behaviour
#   LOGIN_URL          -> where @login_required sends anonymous visitors
#   LOGIN_REDIRECT_URL -> where to go after a successful login
#   LOGOUT_REDIRECT_URL-> where to go after logout
# ---------------------------------------------------------------------------
LOGIN_URL = "tasks:login"
LOGIN_REDIRECT_URL = "tasks:dashboard"
LOGOUT_REDIRECT_URL = "tasks:login"

# Make Django's "error" messages use Bootstrap's "danger" alert colour.
MESSAGE_TAGS = {message_constants.ERROR: "danger"}
