"""
Project-level URL configuration.

When a request arrives, Django looks here first.
 - /admin/...  -> Django's built-in admin site
 - everything else -> handed over to the 'tasks' app (tasks/urls.py)
"""
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("tasks.urls")),
]
